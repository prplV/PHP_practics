﻿<?php
	$db = mysql_connect('localhost', 'root', '');
	mysql_select_db('firma', $db);
	mysql_set_charset('utf8');
	
?>
<html>
	<head></head>
	<body>
		<h1>Обновление данных о сотруднике</h1>
		<?php
			
			if (isset($_REQUEST['id_polz'])) {
				$id_polz = $_REQUEST['id_polz'];
				
				$query_polz = mysql_query("SELECT * FROM sotr WHERE id='$id_polz'");
				$polz = mysql_fetch_array($query_polz);
				
		?>
			<form action='obr_upd.php' method='GET'> 
				Имя <input type='text' name='name_polz' value=<?php echo $polz['name']; ?>> <br><br>
				Фамилия <input type='text' name='fame' value=<?php echo $polz['fame']; ?>> <br><br>
				Отчество <input type='text' name='lname' value=<?php echo $polz['lname']; ?>> <br><br>
				Должность <input type='text' name='dol' value=<?php echo $polz['dol']; ?>> <br><br>
				Зарплата <input type='text' name='zp' value=<?php echo $polz['zp']; ?>> <br><br>
				<input type='hidden' value=<?php echo $polz['id']; ?> name='id_polz' >
				<input type='submit' value='Изменить'>
				<input type='reset' value = 'Очистить форму'>
			</form>
		<?php		
		
			} else {

				$query = mysql_query("SELECT * FROM sotr");
		
				while ($rez_query = mysql_fetch_array($query)) {
					echo "<a href='upd_form.php?id_polz={$rez_query['id']}'>{$rez_query['fame']} {$rez_query['name']} {$rez_query['lname']} {$rez_query['dol']} {$rez_query['zp']}</a><br>";
				}
			}
		?>
	</body>
</html>