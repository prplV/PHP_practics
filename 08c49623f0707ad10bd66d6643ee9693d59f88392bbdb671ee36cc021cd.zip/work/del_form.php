﻿<?php
	$db = mysql_connect('localhost', 'root', '');
	mysql_select_db('firma', $db);
	mysql_set_charset('utf8');
	
?>
<html>
	<head></head>
	<body>
		<h1>Обновление данных о сотруднике</h1>
		<?php
			
		$query = mysql_query("SELECT * FROM sotr");
		
		while ($rez_query = mysql_fetch_array($query)) {
			echo "<a href='obr_del.php?id_polz={$rez_query['id']}'>{$rez_query['fame']} {$rez_query['name']} {$rez_query['lname']} {$rez_query['dol']} {$rez_query['zp']}</a><br>";
		}
		?>
	</body>
</html>