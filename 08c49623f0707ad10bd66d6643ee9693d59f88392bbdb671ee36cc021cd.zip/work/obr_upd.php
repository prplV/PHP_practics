﻿<?php
	$db = mysql_connect('localhost', 'root', '');
	mysql_select_db('firma', $db);
	mysql_set_charset('utf8');
	
	$name = $_REQUEST['name_polz'];
	$fame = $_REQUEST['fame'];
	$lname = $_REQUEST['lname'];
	$dol = $_REQUEST['dol'];
	$zp = $_REQUEST['zp'];
	$id = $_REQUEST['id_polz'];
	
	if ($name != '' && $fame != '' && $lname != '' && $dol != '' && $zp != '') {	
	
		$query_polz = mysql_query("SELECT * FROM sotr WHERE id='$id'");
		if (mysql_fetch_array($query_polz)){
			$query = mysql_query("UPDATE sotr SET name='$name', fame='$fame', lname='$lname', dol='$dol', zp='$zp' WHERE id='$id'");
			if ($query == true) {
				echo "Добавлены изменения! <a href='upd_form.php'>Главная страница</a>";
			} else {
				echo "Произошла ошибка при добавление <a href='upd_form.php?name_polz=$name&fame=$fame&lname=$lname&dol=$dol&zp=$zp'>Главная страница</a>";
			}			
		} else {
			echo "Нет такого пользователя <a href='add_form.php?name_polz=$name&fame=$fame&lname=$lname&dol=$dol&zp=$zp'>Главная страница</a>";
		}
	} else {
		echo "Заполнены не все поля <a href='add_form.php?name_polz=$name&fame=$fame&lname=$lname&dol=$dol&zp=$zp&id_polz=$id'>Главная страница</a>";
	}


?>