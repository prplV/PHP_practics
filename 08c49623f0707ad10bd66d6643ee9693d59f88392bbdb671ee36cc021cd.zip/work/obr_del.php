﻿<?php
	$db = mysql_connect('localhost', 'root', '');
	mysql_select_db('firma', $db);
	mysql_set_charset('utf8');
	
	$id = $_REQUEST['id_polz'];
	$query_polz = mysql_query("SELECT * FROM sotr WHERE id='$id'");
		if (mysql_fetch_array($query_polz)){
			$rez = mysql_query("DELETE FROM sotr WHERE id ='$id'");
			if ($rez == true) {
				echo "Произошло удаление";
			} else {
				echo "Произошла ошибка";
			}
		} else {
			echo "NO";
		}

?>