﻿<?php
	$db = mysql_connect('localhost', 'root', '');
	mysql_select_db('firma', $db);
	mysql_set_charset('utf8');
	
	$name = $_REQUEST['name_polz'];
	$fame = $_REQUEST['fame'];
	$lname = $_REQUEST['lname'];
	$dol = $_REQUEST['dol'];
	$zp = $_REQUEST['zp'];
	
	if ($name != '' && $fame != '' && $lname != '' && $dol != '' && $zp != '') {	
	
		$query_polz = mysql_query("SELECT * FROM sotr WHERE fame='$fame' AND name='$name' AND lname='$lname' AND dol='$dol' AND zp='$zp'");
		if (mysql_fetch_array($query_polz)){
			echo "Такой пользователь уже сущесвует. <a href='add_form.php'>Главная страница</a>";
			// true - существует
		} else {
			// false - пользователя нет
			$query = mysql_query("INSERT INTO sotr (name, fame, lname, dol, zp) VALUES ('$name', '$fame', '$lname', '$dol', '$zp')");
			if ($query == true) {
				echo "Новый сотрудник успешно добавлен! <a href='add_form.php'>Главная страница</a>";
			} else {
				echo "Произошла ошибка при добавление <a href='add_form.php?name_polz=$name&fame=$fame&lname=$lname&dol=$dol&zp=$zp'>Главная страница</a>";
			}
		}
	} else {
		echo "Заполнены не все поля <a href='add_form.php?name_polz=$name&fame=$fame&lname=$lname&dol=$dol&zp=$zp'>Главная страница</a>";
	}




?>	