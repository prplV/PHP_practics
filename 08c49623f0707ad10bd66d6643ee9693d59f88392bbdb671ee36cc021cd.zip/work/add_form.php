﻿<?php
	$name = $_REQUEST['name_polz'];
	$fame = $_REQUEST['fame'];
	$lname = $_REQUEST['lname'];
	$dol = $_REQUEST['dol'];
	$zp = $_REQUEST['zp'];
?>
<html>
	<head></head>
	<body>
		<h1>Добавление нового сотрудника</h1>
		<form action='obr_add.php' method='GET'> 
			Имя <input type='text' name='name_polz' value=<?php echo $name; ?>> <br><br>
			Фамилия <input type='text' name='fame' value=<?php echo $fame; ?>> <br><br>
			Отчество <input type='text' name='lname' value=<?php echo $lname; ?>> <br><br>
			Должность <input type='text' name='dol' value=<?php echo $dol; ?>> <br><br>
			Зарплата <input type='text' name='zp' value=<?php echo $zp; ?>> <br><br>
			<input type='submit' value='Добавить'>
			<input type='reset' value = 'Очистить форму'>
		</form>
	</body>
</html>