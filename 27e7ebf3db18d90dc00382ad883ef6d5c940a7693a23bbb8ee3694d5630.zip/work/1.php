﻿<table border='1' width='500'>
	<tr bgcolor='grey'>
		<td>№</td>
		<td>Фамилия</td>
		<td>Имя</td>
		<td>Отчетсво</td>
		<td>Должность</td>
		<td>Зарплата</td>
	</tr>


<?php
	$db = mysql_connect('localhost', 'root', '');
	mysql_select_db('firma', $db);
	mysql_set_charset('utf8');
	
	if (isset($_REQUEST['que'])) {
		$que = $_REQUEST['que'];
		if ($que == 1) $query = "SELECT * FROM sotr";
		if ($que == 2) $query = "SELECT * FROM sotr WHERE dol='Менеджер' AND zp>='36000'";
		if ($que == 3) $query = "SELECT * FROM sotr ORDER BY zp DESC LIMIT 2";
		if ($que == 4) $query = "SELECT * FROM sotr WHERE dol='Бухгалтер' OR zp<='40000'";
		if ($que == 5) $query = "SELECT * FROM sotr ORDER BY fame";
		if ($que == 6) {
			$min_zp = $_REQUEST['min_zp'];
			if ($min_zp == '') {
				$query_zp = mysql_query("SELECT * FROM sotr ORDER BY zp LIMIT 1");
				$rez_zp = mysql_fetch_array($query_zp);
				$min = $rez_zp['zp'];
				$min_zp = $min;
			}
			
			$max_zp = $_REQUEST['max_zp'];
			
			if ($max_zp == '') {
				$query_zp = mysql_query("SELECT * FROM sotr ORDER BY zp DESC LIMIT 1");
				$rez_zp_max = mysql_fetch_array($query_zp);
				$max = $rez_zp_max['zp'];
				$max_zp = $max;
			}

			$query = "SELECT * FROM sotr WHERE zp>='$min_zp' AND zp<='$max_zp'";
		}
		
		if ($que == 7) {
			$dol = $_REQUEST['sort_dol'];
			$query = "SELECT * FROM sotr WHERE dol='$dol'";
		}
		
	} else {
		$query = "SELECT * FROM sotr";
	}
	
	$rez = mysql_query($query);
	$i = 1;
	while ($mas = mysql_fetch_array($rez)){
		echo "<tr>
			<td>$i</td>
			<td>{$mas['fame']}</td>
			<td>{$mas['name']}</td>
			<td>{$mas['lname']}</td>
			<td>{$mas['dol']}</td>
			<td>{$mas['zp']}</td>
		</tr>";
		$i++;
	}
?>
</table>

	<form action='1.php' method='POST'>
		<input type='radio' value='1' name='que'> Показать всех сотрудников<br>
		<input type='radio' value='2' name='que'> Показать сотрудников с должностью менеджер и зп больше 36000<br>
		<input type='radio' value='3' name='que'> Показать 2-х сотрудников с наиболее высокой зп<br>
		<input type='radio' value='4' name='que'> Показать сотрудников с должностью бухгалтер или у которых зп меньше 40000<br>
		<input type='radio' value='5' name='que'> Отсортировать по алфавиту<br>
		<input type='radio' value='6' name='que'> Показать сотрудников с зп от <input type='text' name='min_zp'> до <input type='text' name='max_zp'><br>
		<input type='radio' value='7' name='que'> Показать сотрудников с должностью: 
		<select name='sort_dol'>
			<?php
				$query_dol = mysql_query("SELECT DISTINCT dol FROM sotr");
				while ($rez_dol = mysql_fetch_array($query_dol)) {
					echo "<option>{$rez_dol['dol']}</option>";
				}
			?>
		</select>
		<br>
		<input type='submit'>
	</form>